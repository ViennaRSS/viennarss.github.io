This Style is inspired by the work of Michael Ostermeier (http://www.blog.de/main/index.php/mosterme/).

Bodo Tasche
http://www.wannawork.de